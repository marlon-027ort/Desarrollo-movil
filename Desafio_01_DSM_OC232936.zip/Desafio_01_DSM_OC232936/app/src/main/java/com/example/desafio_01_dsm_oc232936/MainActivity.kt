package com.example.desafio_01_dsm_oc232936

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editTextMonto: EditText
    private lateinit var editTextPersonas: EditText
    private lateinit var editTextOtro: EditText
    private lateinit var radioGroupPropina: RadioGroup
    private lateinit var switchIVA: Switch
    private lateinit var btnCalcular: Button
    private lateinit var btnLimpiar: Button
    private lateinit var textResultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Referencias
        editTextMonto = findViewById(R.id.editTextMonto)
        editTextPersonas = findViewById(R.id.editTextPersonas)
        editTextOtro = findViewById(R.id.editTextOtro)
        radioGroupPropina = findViewById(R.id.radioGroupPropina)
        switchIVA = findViewById(R.id.switchIVA)
        btnCalcular = findViewById(R.id.btnCalcular)
        btnLimpiar = findViewById(R.id.btnLimpiar)
        textResultado = findViewById(R.id.textResultado)

        // Habilitar campo personalizado si se selecciona "Otro %"
        radioGroupPropina.setOnCheckedChangeListener { _, checkedId ->
            editTextOtro.isEnabled = (checkedId == R.id.radioOtro)
            if (checkedId != R.id.radioOtro) {
                editTextOtro.setText("")
            }
        }

        // Acción calcular
        btnCalcular.setOnClickListener {
            calcularPropina()
        }

        // Acción limpiar
        btnLimpiar.setOnClickListener {
            limpiarCampos()
        }
    }

    private fun calcularPropina() {
        val montoStr = editTextMonto.text.toString()
        val personasStr = editTextPersonas.text.toString()

        // Validaciones iniciales
        if (montoStr.isEmpty() || personasStr.isEmpty()) {
            mostrarMensaje(getString(R.string.error_campos))
            return
        }

        val monto = montoStr.toDoubleOrNull()
        val personas = personasStr.toIntOrNull()

        if (monto == null || monto <= 0) {
            mostrarMensaje(getString(R.string.error_monto))
            return
        }

        if (personas == null || personas <= 0) {
            mostrarMensaje(getString(R.string.error_personas))
            return
        }

        // Obtener porcentaje de propina
        val porcentajePropina = when (radioGroupPropina.checkedRadioButtonId) {
            R.id.radio10 -> 10.0
            R.id.radio15 -> 15.0
            R.id.radio20 -> 20.0
            R.id.radioOtro -> {
                val otroStr = editTextOtro.text.toString()
                val otro = otroStr.toDoubleOrNull()
                if (otro == null || otro < 0) {
                    mostrarMensaje("Porcentaje personalizado inválido.")
                    return
                }
                otro
            }
            else -> {
                mostrarMensaje("Selecciona un porcentaje de propina.")
                return
            }
        }

        // Calcular IVA
        val iva = if (switchIVA.isChecked) monto * 0.16 else 0.0

        // Cálculo
        val propina = monto * porcentajePropina / 100
        val total = monto + propina + iva
        val totalPorPersona = total / personas

        // Mostrar resultado
        val resultado = """
            Propina: $${String.format("%.2f", propina)}
            IVA: $${String.format("%.2f", iva)}
            Total a pagar: $${String.format("%.2f", total)}
            Monto por persona: $${String.format("%.2f", totalPorPersona)}
        """.trimIndent()

        textResultado.text = resultado
    }

    private fun limpiarCampos() {
        editTextMonto.setText("")
        editTextPersonas.setText("")
        editTextOtro.setText("")
        radioGroupPropina.clearCheck()
        switchIVA.isChecked = false
        editTextOtro.isEnabled = false
        textResultado.text = getString(R.string.resultado)
    }

    private fun mostrarMensaje(mensaje: String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
    }
}
